from datetime import datetime

aktualny_czas = datetime.now()
