from .ambulance import Ambulance

__all__ = ["Ambulance"]
