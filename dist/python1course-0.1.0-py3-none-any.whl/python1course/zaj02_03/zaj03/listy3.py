# Zadanie 3

wynik = [str(x) for x in range(1, 51) if x % 3 == 0 and x % 5 == 0]
print(wynik)
