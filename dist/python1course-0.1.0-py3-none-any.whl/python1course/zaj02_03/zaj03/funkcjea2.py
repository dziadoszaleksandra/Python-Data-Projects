# Zadanie 2

obie_parzyste = lambda x, y: x % 2 == 0 and y % 2 == 0

print(obie_parzyste(2, 4))  # true
print(obie_parzyste(2, 5))  # false
print(obie_parzyste(7, 9))  # false
