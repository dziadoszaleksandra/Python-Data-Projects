# Zadanie 1

kwadraty = [x**2 for x in range(1, 21) if x % 3 == 0]
print(kwadraty)
