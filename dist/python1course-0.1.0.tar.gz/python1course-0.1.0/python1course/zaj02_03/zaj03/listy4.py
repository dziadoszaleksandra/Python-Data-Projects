# Zadanie 4

lista_list = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
splaszczone_kwadraty = [x**2 for podlista in lista_list for x in podlista]
print(splaszczone_kwadraty)
