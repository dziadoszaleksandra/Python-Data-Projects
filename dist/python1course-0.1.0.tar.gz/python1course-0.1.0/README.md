# python1-course

Materiały dostępne na stronie [Python 1 - Materials](https://eo-agh.github.io/python1-materials).
